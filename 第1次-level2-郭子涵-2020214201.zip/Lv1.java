import java.util.Scanner;

public class Lv1 {
    public static void main(String[] args) {
        int[] arr1 = {15,25,10,30,40,20,50};
        //排序
        for (int i = 0; i < arr1.length; i++) {
            for (int j = 0; j < arr1.length-1; j++) {
                if (arr1[j] > arr1[j+1]) {
                    arr1[j] = arr1[j]^arr1[j+1];
                    arr1[j+1] = arr1[j]^arr1[j+1];
                    arr1[j] = arr1[j]^arr1[j+1];
                }
            }
        }
        System.out.println("冒泡排序后的结果:");
        for (int i = 0; i < arr1.length; i++) {
            System.out.printf("%d ",arr1[i]);
        }
        //输入
        System.out.println("\n请输入一个待插入的数:");
        Scanner scan = new Scanner(System.in);
        int insert = scan.nextInt();
        System.out.println(insert);
        //插入
        int alen = arr1.length;
        int[] arr2 = new int[alen+1];
        for (int i = 0; i < alen; i++) {
            if (arr1[i] >= insert){
                for (int j = i; j < alen ; j++) { arr2[j+1]=arr1[j]; }
                arr2[i] = insert;
                break;
            }else arr2[i] = arr1[i];
        }
        System.out.printf("插入数字（%d）之后的数组为:",insert);
        for (int i = 0; i < arr2.length; i++) {
            System.out.printf("%d ",arr2[i]);
        }
    }
}
