import java.util.Scanner;

public class Lv2 {
    public static void main(String[] args) {
        //输入
        System.out.println("请为对称矩阵输入行列数");
        Scanner scan = new Scanner(System.in);
        int a = scan.nextInt();
        //随机赋值
        int[][] arr1 = new int[a][a];
        int[][] arr2 = new int[a][a];
        for (int i = 0; i < a; i++) {
            for (int j = 0; j < a; j++) {
                arr1[i][j] = (int) (Math.random()*5);
            }
        }
        for (int i = 0; i < a; i++) {
            for (int j = 0; j < a; j++) {
                arr2[i][j] = (int) (Math.random()*5);
            }
        }
        //输出矩阵
        System.out.println("随机对称矩阵A:");
        for (int i = 0; i < a; i++) {
            for (int j = 0; j < a; j++) {
                System.out.printf("%d ",arr1[i][j]);
            }
            System.out.println();
        }
        System.out.println("随机对称矩阵B:");
        for (int i = 0; i < a; i++) {
            for (int j = 0; j < a; j++) {
                System.out.printf("%d ",arr2[i][j]);
            }
            System.out.println();
        }
        //矩阵A，B乘积
        int[][] arr3 = new int[a][a];
        for (int i = 0; i < a; i++) {
            for (int j = 0; j < a; j++) {
                for (int k = 0; k < a; k++) {
                    arr3[i][j] += arr1[i][k] * arr2[k][j];
                }
            }
        }
        System.out.println("相乘后的对称矩阵:");
        for (int i = 0; i < a; i++) {
            for (int j = 0; j < a; j++) {
                System.out.printf("%d ",arr3[i][j]);
            }
            System.out.println();
        }
        //对角线之和
        int sum=0;
        for (int i = 0; i < a; i++) {
            sum+=arr3[i][i];
        }
        System.out.printf("此矩阵对角线的和为:");
        System.out.println(sum);
    }
}
